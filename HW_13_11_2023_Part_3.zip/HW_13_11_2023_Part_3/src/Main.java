import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Напишите программу, которая получает от пользователя два целых числа и затем
        // вычисляет сумму (сложение), разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
        // Результат вычисления выведите в консоль.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите целое число №1:");
        int num1 = scr.nextInt();
        System.out.println("Введите целое число №2:");
        int num2 = scr.nextInt();
        System.out.println("Сумма сложения:" + (num1+num2));
        System.out.println("Разность вычитания:" + (num1-num2));
        System.out.println("Частное деления:" + (num1/num2));
        System.out.println("Произведение умножения:" + (num1*num2));
    }
}