import wedding.Year;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Задание 1.
        //Пользователь вводит, сколько лет он состоит в браке.
        // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей (бумажная, ситцевая, чугунная, серебряная и.д.).
        // Не обязательно указывать все годовщины, достаточно 10-15.
        // Узнать про годовщины можно, например, здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        System.out.println("Введите количество лет в браке: ");

        System.out.println(Arrays.toString(Year.values()));
        Scanner scr = new Scanner(System.in);
        int numUser = scr.nextInt();
        Year year = switch (numUser) {
            case 1 -> Year.CALICO;
            case 2 -> Year.PAPER;
            case 3 -> Year.LEATHER;
            case 4 -> Year.LINEN;
            case 5 -> Year.WOODEN;
            case 6 -> Year.CAST_IRON;
            case 7 -> Year.COPPER;
            case 8 -> Year.TIN;
            case 9 -> Year.EARTHENWARE;
            case 10 -> Year.STANNIC;
            case 11 -> Year.STEEL;
            case 12 -> Year.NICKEL;
            case 13 -> Year.LACE;
            case 14 -> Year.AGATE;
            case 15 -> Year.CRYSTAL;
            case 16 -> Year.TOPAZ;
            case 17 -> Year.PINK;
            case 18 -> Year.TURQUOISE;
            case 19 -> Year.GARNET;
            case 20 -> Year.PORCELAIN;
            case 21 -> Year.OPAL;
            case 22 -> Year.BRONZE;
            case 23 -> Year.BERYL;
            case 24 -> Year.SATIN;
            case 25 -> Year.SILVER;
            case 26 -> Year.JADE;
            case 27 -> Year.RED_TREE;
            case 28 -> Year.PALLADIUM;
            case 29 -> Year.VELVET;
            case 30 -> Year.PEARL;
            case 31 -> Year.SUNNY;
            case 32 -> Year.COPPER;
            case 33 -> Year.STONE;
            case 34 -> Year.AMBER;
            case 35 -> Year.CORAL;
            case 36 -> Year.BONE_PHARFOR;
            case 37 -> Year.MUSLIN;
            case 38 -> Year.MERCURY;
            case 39 -> Year.CREPE;
            case 40 -> Year.RUBY;
            case 41 -> Year.IRON;
            case 42 -> Year.MOTHER_OF_PEARL;
            case 43 -> Year.FLANNEL;
            case 44 -> Year.TOPAZZ;
            case 45 -> Year.SAPPHIRE;
            case 46 -> Year.LAVENDER;
            case 47 -> Year.CASHMERE;
            case 48 -> Year.AMETHYST;
            case 49 -> Year.CEDAR;
            case 50 -> Year.GOLD;
            case 55 -> Year.EMERALD;
            case 60 -> Year.DIAMOND;
            case 65 -> Year.IRON_BIG;
            case 70 -> Year.THIEVES;
            case 75 -> Year.CROWN;
            case 80 -> Year.OAK;
            case 90 -> Year.GRANITE;
            case 100 -> Year.RED;
            default ->  Year.UNKNOWN;
        };
        System.out.println(year == Year.UNKNOWN ? "Не знаю" : year);
    }
}