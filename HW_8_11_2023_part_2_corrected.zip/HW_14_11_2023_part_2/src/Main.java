public class Main {
    public static void main(String[] args) {
       int abc =987;
       int a = abc/100;
       int b = (abc/10)%10;
       int c = abc%10;
        System.out.println(a + "," + b + "," + c);



        //Дано трехзначное число. Вывести на экран все цифры этого числа
        //Пример: 345
        //Вывод в консоль: Число 345 -> 3, 4, 5
        //Другой пример: 987
        //Вывод в консоль: Число 987 -> 9, 8, 7
    }
}