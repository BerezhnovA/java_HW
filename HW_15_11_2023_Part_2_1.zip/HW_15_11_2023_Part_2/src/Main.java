import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”
        System.out.println("Введите сумму Рублей покупок: ");
        Scanner scr = new Scanner(System.in);
        int sumX = scr.nextInt();
        System.out.println("Введите сумму копеек покупок: ");
        Scanner scr2 = new Scanner(System.in);
        int sumY = scr.nextInt();
        System.out.println("Введите сумму Рублей которую дал покупатель: ");
        Scanner scr3 = new Scanner(System.in);
        int sum2X = scr.nextInt();
        System.out.println("Введите сумму копеек которую дал покупатель: ");
        Scanner scr4 = new Scanner(System.in);
        int sum2Y = scr.nextInt();
        System.out.println("Сумма сдачи: " +(sum2X-sumX) + " рублей и " + (sum2Y-sumY) + " копеек" );
    }
}