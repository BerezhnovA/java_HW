package choices;

public enum Choices {
    STONE,
    PAPPER,
    SCISSORS
}
