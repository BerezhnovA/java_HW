import choices.Choices;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите один из вариантов");
        System.out.println(Arrays.toString(Choices.values()));
        String userStr = sc.nextLine();
        Choices user = Choices.valueOf(userStr.toUpperCase(Locale.ROOT));
        Random rnd = new Random();
        int compNum = rnd.nextInt(3);
        Choices comp = switch (compNum) {
            case 0 -> Choices.STONE;
            case 1 -> Choices.PAPPER;
            default -> Choices.SCISSORS;
        };
        System.out.println(comp);
        if (user == comp)
            System.out.println("Ничья");
        else if (user == Choices.STONE && comp == Choices.SCISSORS ||
                user == Choices.SCISSORS && comp == Choices.PAPPER ||
                user == Choices.PAPPER && comp == Choices.STONE)
            System.out.println("Победил пользователь!");
        else System.out.println("Победил компьютер!");
    }
}