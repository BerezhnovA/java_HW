import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //1 Напишите программу, в которой объявите переменные всех примитивных типов.
        // Значение для каждой переменной сгенерируйте с помощью класса Random.
        // При необходимости используйте приведение типов. Полученные значения выведите в консоль.
        //2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
        // При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет.
        // Полученное значение выведите в консоль.
        boolean bl;
        char ch;
        byte bt;
        short sh;
        int i;
        long l;
        float f;
        double d;
        Random rnd = new Random();
        bl = (boolean) rnd.nextBoolean();
        ch = (char) rnd.nextInt(65536);
        bt = (byte) rnd.nextInt (-128,128);
        sh = (short) rnd.nextInt(-32786,32768);
        i = rnd.nextInt();
        l = rnd.nextLong();
        f = rnd.nextFloat();
        d = rnd.nextDouble();
        System.out.println(bl);
        System.out.println(ch);
        System.out.println(bt);
        System.out.println(sh);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
        int isI = rnd.nextInt();
        System.out.println(String.valueOf(isI));






    }
}