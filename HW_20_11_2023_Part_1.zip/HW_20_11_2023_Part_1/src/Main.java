public class Main {
    public static void main(String[] args) {
        // Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        // Числа могут быть, как целочисленные, так и дробные.
        // Например:
        // ввод : m=7, n=11
        // вывод: Число 11 ближе к 10.
        double m = 7;
        double n = 11;
        double xm = Math.abs(10-m);
        double xn = Math.abs(10-n);
        if (xm < xn)
            System.out.println(m);
        else System.out.println(n);
    }
}