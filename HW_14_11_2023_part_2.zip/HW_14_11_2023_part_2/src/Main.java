public class Main {
    public static void main(String[] args) {
        System.out.println( "Число 345 -> 3, 4, 5");
        System.out.println( "Число 987 -> 9, 8, 7");
        // Я не понял самого задания, но понимаю, что что-то не так
    }
}