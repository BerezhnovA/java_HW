import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№3 Элвис Пресли жил с 1935 по 1977 год.
        // Используя тернарные операторы, напишите программу, в которой пользователь вводит год.
        // Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
        // Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
        // Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
        int elvisWasBorn = 1935;
        int elvisDead = 1977;
        System.out.println("Введите год: ");
        Scanner scr = new Scanner(System.in);
        int yearUser = scr.nextInt();
        System.out.println(yearUser > elvisWasBorn ? (yearUser < elvisDead ? "Элвис жив" : "Элвис навсегда в наших сердцах!") : "Элвис навсегда в наших сердцах!");
    }
}