public class Main {
    public static void main(String[] args) {
        char ch = 71;
        int in = 89;
        byte bt = 4;
        short sh = 56;
        float fl = 4.355453532f;
        double db = 4.355453532;
        long lg = 12121;
        System.out.println(ch);
        System.out.println(in);
        System.out.println(bt);
        System.out.println(sh);
        System.out.println(fl);
        System.out.println(db);
        System.out.println(lg);
    }
}