import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”
        System.out.println("Введите сумму покупок: ");
        Scanner scr = new Scanner(System.in);
        double price = scr.nextDouble();
        System.out.println("Введите сумму копеек которую дал покупатель: ");
        double money = scr.nextDouble();
        double change = money - price;
        int rub = (int)change;
        int kop = (int)((change-rub)*100);
        System.out.println();
        System.out.println("Сумма сдачи: " +rub + " рублей и " + kop + " копеек" );
    }
}