public class Main {
    public static void main(String[] args) {
       int number =345;
       char ch = ',';
        System.out.println(number/100 + "," + number/(number/4) + "," + number%10);
        number = 987;
        System.out.printf(number/100 + "," + number/(number/8) + "," + number%10);


        //Дано трехзначное число. Вывести на экран все цифры этого числа
        //Пример: 345
        //Вывод в консоль: Число 345 -> 3, 4, 5
        //Другой пример: 987
        //Вывод в консоль: Число 987 -> 9, 8, 7
    }
}